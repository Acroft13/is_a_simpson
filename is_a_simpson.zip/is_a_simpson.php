<html lang="en">
<!--/*Author: Amy Croft
Assignment: 8
Course: DGL123
Date: October 26, 2021*/-->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Is a Simpson</Index></title>
</head>

<body>

<?php


$simpsons = [
    'Homer Simpson',
    'Marge Simpson',
    'Lisa Simpson',
    'Bart Simpson',
    'Maggie Simpson'

];
echo var_dump ($simpsons);

function is_a_simpson($full_name) {
    // Complete this function

    //create variables for first and last names
    //target last name
    //Test
    //if last name in var dump is in $simpsons return true/ else return false echo ' You are not a Simpson'
    
     foreach ($simpsons as $simpson) {
        $lastname = $simpson;
        // $lastname = $item
        // $last = strtok($_POST['name'],',');
        if ($lastname == 'simpson' ) {
        return true;
    }
}
    return false;
}

var_dump(is_a_simpson('Lisa Simpson')); // This should return true
var_dump(is_a_simpson('Marge Simpson')); // This should return true
var_dump(is_a_simpson('Ned Flanders')); // This should return false
var_dump(is_a_simpson('Montgomery Burns')); // This should return false
var_dump(is_a_simpson('Simpson Harris')); // This should return false



?>
</body>
</html>